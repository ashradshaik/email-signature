document.addEventListener("touchstart", function(){}, true);





// Place raw HTML of each version into appropriate containers
function updateHtmlSigRaw() {

get_html_signature = $("#standard-target").clone(true);
$(get_html_signature).find('*[style*="display: none"]').remove();
$(get_html_signature).html();

$("#html code").text($(get_html_signature).html());
  $("#html code").prepend('&lt;style&gt; @import url(//overpass-30e2.kxcdn.com/overpass.css); &lt;/style&gt;').text;
}
 


$(".promo").hide();

$(".promo-selector input[type=radio]").on("change", function(){
  if(document.getElementById('promo-1').checked) {   $(".promo").show();$(".promo-1").show();$(".promo-2").hide();$(".promo-3").hide();}
  if(document.getElementById('promo-2').checked) {   $(".promo").show();$(".promo-2").show();$(".promo-1").hide();$(".promo-3").hide();}
  if(document.getElementById('promo-3').checked) {   $(".promo").show();$(".promo-3").show();$(".promo-1").hide();$(".promo-2").hide();}
  if(document.getElementById('nopromo').checked) {   $(".promo").hide();$(".promo-1").hide();$(".promo-2").hide();$(".promo-3").hide();}

  updateHtmlSigRaw()
});




// SOCIAL
$(".social").show();
$(".social-selector input[type=radio]").on("change", function(){
  if(document.getElementById('social-1').checked) {   $(".social").show();$(".social-1").show();$(".social-2").hide();$(".social-3").hide();}
  if(document.getElementById('social-2').checked) {   $(".social").show();$(".social-2").show();$(".social-1").hide();$(".social-3").hide(); }
  if(document.getElementById('social-3').checked) {   $(".social").show();$(".social-3").show();$(".social-1").hide();$(".social-2").hide();}
  if(document.getElementById('nosocial').checked) {   $(".social").hide();$(".social-1").hide();$(".social-2").hide();$(".social-3").hide();}

  updateHtmlSigRaw()
});


$(".contact-container").hide();

//
// department
$(".department-container").hide();
$("input.department").on("change keyup paste", function(){
  var department = $(this).val();
  //alert(department);
  if(department) {
    $(".contact-container").show();
    $(".department-container").show();
    $(".department-container span").html(department);
  }
else {$(".department-container").hide();
}

  updateHtmlSigRaw()
});



$(".contact-container").hide();
//
// department adress
$(".department-adress-container").hide();
$("input.departmentAdress").on("change keyup paste", function(){
  var departmentAdress = $(this).val();
  //alert(department);
  if(departmentAdress) {
     $(".contact-container").show();
    $(".department-adress-container").show();
    $(".department-adress-container span").html('<b class="bar">&nbsp; | &nbsp;</b>'+departmentAdress);
  }
else {$(".department-adress-container").hide();
}

  updateHtmlSigRaw()
});



//
// address
$(".address-container").hide();
$("input.address").on("change keyup paste", function(){
  var address = $(this).val();
  if(address) {
    $(".address-container").show();
    $(".address-container span").html(address);
  }
else {$(".address-container").hide();
}

  updateHtmlSigRaw()
});



//
// address
$(".address2-container").hide();
$("input.address2").on("change keyup paste", function(){
  var address2 = $(this).val();
  if(address2) {
    $(".address2-container").show();
    $(".address2-container span").html(address2);
  }
else {$(".address2-container").hide();
}
  updateHtmlSigRaw()
});


//
// fingerprint
$(".fingerprint-container").hide();
$("input.fingerprint").on("change keyup paste", function(){
  var fingerprint = $(this).val();
  if(fingerprint) {
    $(".fingerprint-container").show();
    $(".fingerprint-container span").html(fingerprint);
  }
else {$(".fingerprint-container").hide();
}
  updateHtmlSigRaw()
});



//
// certifications
$(".cert").hide();
$("input.certs").on("change keyup paste", function(){
  var cert = $(this).val();
  if(cert) {

    $(".position-container").show();
    $(".cert").show();
    $(".cert span").html(cert);
  }
else {$(".cert").hide();
}
  updateHtmlSigRaw()
});




$(".contact-container").hide();

//
// telephone
$(".telephone-container").hide();

$("input.telephone").on("change keyup paste", function(){
  var telephone = $(this).val().split(" ").join("-").toUpperCase();
  if(telephone) {
    $(".contact-container").show();
    $(".telephone-container").show();
    $(".telephone-container a").html(telephone)

        $(".telephone-container a").attr("href", "tel:"+telephone);


  }
else {$(".telephone-container").hide();
}

  updateHtmlSigRaw()
});


//
// mobile
$(".mobile-container").hide();

$("input.mobile").on("change keyup paste", function(){
  var mobile = $(this).val().split(" ").join("-").toUpperCase();
  if(mobile) {
    $(".mobile-container").show();
    $(".contact-container").show();
    $(".mobile-container a").html(mobile);
        $(".mobile-container a").attr("href", "tel:"+mobile);
  }
else {$(".mobile-container").hide();
}

  updateHtmlSigRaw()
});



//
// fax
$(".fax-container").hide();

$("input.fax").on("change keyup paste", function(){
  var fax = $(this).val().split(" ").join("-").toUpperCase();
  if(fax) {
    $(".fax-container").show();
    $(".contact-container").show();
    $(".fax-container a").html(fax);
    $(".fax-container a").attr("href", "tel:"+fax);

  }
else {$(".fax-container").hide();
}

  updateHtmlSigRaw()
});


//social media
//facebook



var barLine = '<b class="bar">&nbsp; | &nbsp;</b>';

$('.social-media-container').hide();

$('.media-social-two, .media-social-three, .media-social-four, .media-social-five').hide();

$('select.social-media-one').on('change keyup', function(){
  var selectOne = $(this).val();
  if(selectOne != 'null'){
    $('.media-social-one input').on('change keyup paste', function(){
      var value = $(this).val();      
      $('span.media-1').show();
      if(value){
        $('.social-media-container').show();
        $('.social-media-container span.media-1').html('<a href="'+value+'" style="color:#0088ce;font-size:16px;margin:0;text-decoration:none !important;font-family: Calibri,Candara,Segoe,Segoe UI,Optima,Arial,sans-serif;text-transform: capitalize;">'+selectOne+'</a>');
      
        setTimeout(function(){
          $('.media-social-two').show();
        },400);
      }
    });
  }else {
    $('span.media-1, span.media-2, span.media-3, span.media-4, span.media-5').hide();
    $('.media-social-two, .media-social-three, .media-social-four, .media-social-five').hide();
  }
});

$('select.social-media-two').on('change keyup', function(){
  var selectTwo = $(this).val();
  if(selectTwo != 'null'){
    $('.media-social-two input').on('change keyup paste', function(){
      var value = $(this).val();      
        $('span.media-2').show();
      if(value){
        $('.social-media-container span.media-2').html(barLine + '<a href="'+value+'" style="color:#0088ce;font-size:16px;margin:0;text-decoration:none !important;font-family: Calibri,Candara,Segoe,Segoe UI,Optima,Arial,sans-serif;text-transform: capitalize;">'+selectTwo+'</a>');
      
        setTimeout(function(){
          $('.media-social-three').show();
        },400);
      }
    });
  }else{
    $('span.media-2, span.media-3, span.media-4, span.media-5').hide();
    $('.media-social-three, .media-social-four, .media-social-five').hide();
  }
});

$('select.social-media-three').on('change keyup', function(){
  var selectThree = $(this).val();
  if(selectThree != 'null'){
    $('.media-social-three input').on('change keyup paste', function(){
      var value = $(this).val();
        $('span.media-3').show();
      if(value){
        $('.social-media-container span.media-3').html(barLine + '<a href="'+value+'" style="color:#0088ce;font-size:16px;margin:0;text-decoration:none !important;font-family: Calibri,Candara,Segoe,Segoe UI,Optima,Arial,sans-serif;text-transform: capitalize;">'+selectThree+'</a>');
      
        setTimeout(function(){
          $('.media-social-four').show();
        },400);
      }
    });
  }else{
    $('span.media-3, span.media-4, span.media-5').hide();
    $('.media-social-four, .media-social-five').hide();
  }
});

$('select.social-media-four').on('change keyup', function(){
  var selectFour = $(this).val();
  if(selectFour != 'null'){
    $('.media-social-four input').on('change keyup paste', function(){
      var value = $(this).val();
        $('span.media-4').show();
      if(value){
        $('.social-media-container span.media-4').html(barLine + '<a href="'+value+'" style="color:#0088ce;font-size:16px;margin:0;text-decoration:none !important;font-family: Calibri,Candara,Segoe,Segoe UI,Optima,Arial,sans-serif;text-transform: capitalize;">'+selectFour+'</a>');
      
        setTimeout(function(){
          $('.media-social-five').show();
        },400);
      }
    });
  }else{
    $('span.media-4, span.media-5').hide();
    $('.media-social-five').hide();
  }
});

$('select.social-media-five').on('change keyup', function(){
  var selectFive = $(this).val();
  if(selectFive != 'null'){
    $('.media-social-five input').on('change keyup paste', function(){
      var value = $(this).val();
        $('span.media-5').show();
      if(value){
        $('.social-media-container span.media-5').html(barLine + '<a href="'+value+'" style="color:#0088ce;font-size:16px;margin:0;text-decoration:none !important;font-family: Calibri,Candara,Segoe,Segoe UI,Optima,Arial,sans-serif;text-transform: capitalize;">'+selectFive+'</a>');
      }
    });
  }else{
    $('span.media-5').hide();
  }
});




/*$('select.social-media-links').on('change keyup', function(){
  var selectValue = $(this).val();
  //alert(selectValue);
  if(selectValue == 'facebook'){
    facebook.show();
    twitter.hide();
    instagram.hide();
    linkedin.hide();
    pinterest.hide();
    $(facebook).on('change keyup paste', function(){
      var faceValue = $(this).val(); 
      if(faceValue) {
        $('.social-media-container').show();
        $('.facebook-container').show();
        $('.facebook-container').html('<a href="" style="color:#0088ce;font-size:16px;margin:0;text-decoration:none !important;font-family: Calibri,Candara,Segoe,Segoe UI,Optima,Arial,sans-serif;text-transform: capitalize;">facebook</a>');
        $('.facebook-container a').attr('href', faceValue);
       }
       else{
        $('.facebook-container').hide();
       } 
    });
  }else if(selectValue == 'twitter'){
    twitter.show();
    facebook.hide();
    instagram.hide();
    linkedin.hide();
    pinterest.hide();
    $(twitter).on('change keyup paste', function(){
      var twiValue = $(this).val(); 
      if(twiValue) {
        $('.social-media-container').show();
        $('.twitter-container').show();
        $('.twitter-container').html('<a href="" style="color:#0088ce;font-size:16px;margin:0;text-decoration:none !important;font-family: Calibri,Candara,Segoe,Segoe UI,Optima,Arial,sans-serif;text-transform: capitalize;">twitter</a>');
        $('.twitter-container a').attr('href', twiValue);
       }
       else{
        $('.twitter-container').hide();
       } 
    });
  }
  else if(selectValue == 'instagram'){
    twitter.hide();
    facebook.hide();
    instagram.show();
    linkedin.hide();
    pinterest.hide();
    
    $(instagram).on('change keyup paste', function(){
      var insValue = $(this).val(); 
      if(insValue) {
        $('.social-media-container').show();
        $('.instagram-container').show();
        $('.instagram-container').html('<a href="" style="color:#0088ce;font-size:16px;margin:0;text-decoration:none !important;font-family: Calibri,Candara,Segoe,Segoe UI,Optima,Arial,sans-serif;text-transform: capitalize;">instagram</a>');
        $('.instagram-container a').attr('href', insValue);
       }
       else{
        $('.instagram-container').hide();
       } 
    });
  }
  else if(selectValue == 'linkedin'){
    twitter.hide();
    facebook.hide();
    instagram.hide();
    linkedin.show();
    pinterest.hide();
    
    $(linkedin).on('change keyup paste', function(){
      var linValue = $(this).val(); 
      if(linValue) {
        $('.social-media-container').show();
        $('.linkedin-container').show();
        $('.linkedin-container').html('<a href="" style="color:#0088ce;font-size:16px;margin:0;text-decoration:none !important;font-family: Calibri,Candara,Segoe,Segoe UI,Optima,Arial,sans-serif;text-transform: capitalize;">linkedin</a>');
        $('.linkedin-container a').attr('href', linValue);
       }
       else{
        $('.linkedin-container').hide();
       } 
    });
  }
  else if(selectValue == 'pinterest'){
    twitter.hide();
    facebook.hide();
    instagram.hide();
    linkedin.hide();
    pinterest.show();
    
    $(pinterest).on('change keyup paste', function(){
      var pinValue = $(this).val(); 
      if(pinValue) {
        $('.social-media-container').show();
        $('.pinterest-container').show();
        $('.pinterest-container').html('<a href="" style="color:#0088ce;font-size:16px;margin:0;text-decoration:none !important;font-family: Calibri,Candara,Segoe,Segoe UI,Optima,Arial,sans-serif;text-transform: capitalize;">pinterest</a>');
        $('.pinterest-container a').attr('href', pinValue);
       }
       else{
        $('.pinterest-container').hide();
       } 
    });
  }
});*/


/*$('input.facebook').on('change keyup paste', function(){
  var facebook = $(this).val();
  if(facebook){
    $('.social-media-container').show();
    $('.facebook-container').show();
    $('.facebook-container').html('<a href="" style="color:#0088ce;font-size:16px;margin:0;text-decoration:none !important;font-family: Calibri,Candara,Segoe,Segoe UI,Optima,Arial,sans-serif;text-transform: capitalize;">facebook</a>');
    $('.facebook-container a').attr('href', facebook);
  }
  else{
    $('.facebook-container').hide();
  }
});

//twitter
 $('.twitter-container').hide();

$('input.twitter').on('change keyup paste', function(){
  
  
  var twitter = $(this).val();
  if(twitter){
    $('.social-media-container').show();
    $('.twitter-container').show();
    $('.twitter-container').html('<a href="" style="color:#0088ce;font-size:16px;margin:0;text-decoration:none !important;font-family: Calibri,Candara,Segoe,Segoe UI,Optima,Arial,sans-serif;text-transform: capitalize;" >twitter</a>');
    //$('.twitter-container a').html('<b class="bar">&nbsp; | &nbsp;</b>twitter');
    $('.twitter-container a').attr('href', twitter);
  }
  else{
    $('.twitter-container').hide();
  }   
});



//instagram
$('.instagram-container').hide();

$('input.instagram').on('change keyup paste', function(){
  var instagram = $(this).val();
  if(instagram){
    $('.social-media-container').show();
    $('.instagram-container').show();
    $('.instagram-container').html('<a href="" style="color:#0088ce;font-size:16px;margin:0;text-decoration:none !important;font-family: Calibri,Candara,Segoe,Segoe UI,Optima,Arial,sans-serif;text-transform: capitalize;" >instagram</a>');
    $('.instagram-container a').attr('href', instagram);
  }
  else{
    $('.instagram-container').hide();
  }
});



//linkedin
$('.linkedin-container').hide();
$('input.linkedin').on('change keyup paste', function(){
  var linkedin = $(this).val();
  if(linkedin){
    $('.social-media-container').show();
    $('.linkedin-container').show();
    $('.linkedin-container').html('<a href="" style="color:#0088ce;font-size:16px;margin:0;text-decoration:none !important;font-family: Calibri,Candara,Segoe,Segoe UI,Optima,Arial,sans-serif;text-transform: capitalize;" >linkedIn</a>');
    $('.linkedin-container a').attr('href', linkedin);
  }
  else{
    $('.linkedin-container').hide();
  }
});



//pinterest
$('.pinterest-container').hide();
$('input.pinterest').on('change keyup paste', function(){
  var pinterest = $(this).val();
  if(pinterest){
    $('.social-media-container').show();
    $('.pinterest-container').show();
    $('.pinterest-container').html('<a href="" style="color:#0088ce;font-size:16px;margin:0;text-decoration:none !important;font-family: Calibri,Candara,Segoe,Segoe UI,Optima,Arial,sans-serif;text-transform: capitalize;" >pinterest</a>');
    $('.pinterest-container a').attr('href', pinterest);
  }
  else{
    $('.pinterest-container').hide();
  }
});*/


//
// fullname

$("input.fullname").on("change keyup paste", function(){
  var fullname = $(this).val();
  if(fullname) {
    $(".fullname-container").show();
    $(".firstname-container").show();
    $(".firstname-container").html(fullname);
  }
else {
}

  updateHtmlSigRaw();
});

//logo

//$('.logo').hide();
$('input.logoYesNo').prop('checked', true);
$('input.logoYesNo').on('click', function(){
 var result = $(this).prop('checked');
if(result == true){
      $('.logo').show();
  }
  else{
    $('.logo').hide();
  }
});



//
// im
$(".im-container").hide();

$("input.im").on("change keyup paste", function(){
  var im = $(this).val();
  if(im) {

    $(".contact-container").show();
    $(".im-container").show();
    $(".im-container span").html(im);
  }
else {
  $(".im-container").hide();

}

  updateHtmlSigRaw()
});


$(".degree-container").hide();

//
// lastname

$("input.degree").on("change keyup paste", function(){
  var degree = $(this).val();
  if(degree) {
    $(".fullname-container").show();
    $(".degree-container").show();
    $(".degree-container").html(',&nbsp;'+degree);
  }
else {
$(".degree-container").hide();
}

  updateHtmlSigRaw()
});

//
// legal entity

$("input.legal").on("change keyup paste", function(){
  var legal = $(this).val();
  if(legal) {
    $(".legal-container").show();
    $(".legal-container span").html(legal);
  }
else {
//  $(".legal-container").hide();

}

  updateHtmlSigRaw()
});


//
// Position
$(".position-container").hide();

$("input.position").on("change keyup paste", function(){
  var position = $(this).val();
  if(position) {
    $(".position-container").show();
    $(".position-container .position").html(position);
  }
else {$(".position-container").hide();
}

  updateHtmlSigRaw()
});







//
// Email address
// Check input field for data
$(".email-container").hide();

$(".email").on("change keyup paste", function(){
  var email = $(this).val();
  if(email) {
        $(".email-container").show();
        $(".contact-container").show();

    $(".email-anchor").html(email);
    $(".email-anchor").attr("href", "mailto:"+email);
  } else {
  }
  updateHtmlSigRaw()
});









//// clipboard time

new Clipboard('.btn', {
  text: function (trigger) {

    var targetId = trigger.getAttribute('standard-target');
    $(get_html_signature).find('*[style*="display: none"]').remove();
    $(get_html_signature).html();

    var signature = document.querySelector(targetId).innerHTML;
    signature =  signature.replace(/class="[^"]*"/g, '')
                          .replace(/id="[^"]*"/g, '');
      return signature;
  }
});
